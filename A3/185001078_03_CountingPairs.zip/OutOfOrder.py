import sys
import math
import time
import random
def pairs(arr):

	count=0
	for i in range(len(arr)):
		for j in range(i,len(arr)):
			if(arr[i]>arr[j]):		
				count+=1
	return count

print("Enter size: ")
n=int(input())

arr=[]
for i in range(n):
	arr.append(random.randint(1,9))	

print(arr)
#print("Enter sequence: ")
#arr=[int(i) for i in input().split()]

start=time.time()
print("No. of out of order pairs",pairs(arr))
end=time.time()

print("Time: ",end-start)
